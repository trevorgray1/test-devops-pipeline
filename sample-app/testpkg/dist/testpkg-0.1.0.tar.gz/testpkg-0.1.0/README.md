# testpkg

A simple Python package for testing Cloudsmith uploads.
